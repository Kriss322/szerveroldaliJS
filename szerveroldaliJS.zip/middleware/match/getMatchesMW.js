/**
 * Load all matches from the database
 * The result is saved to res.locals.matches
 */
const requireOption = require('../requireOption');

module.exports = function (objectrepository) {
    return function (req, res, next) {
        next();
    };
};